﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Pilha
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*Stack<int> stack = new Stack<int>();
            stack.Push(1);
            stack.Push(12);
            stack.Push(4551);
            stack.Push(71);
            stack.Push(98);

            foreach (var item in stack)
            {
                Console.Write(item);
            }*/









            /*Stack<int> nomePilha = new Stack<int>();

            nomePilha.Push(6);
            nomePilha.Push(100);
            nomePilha.Push(5);
            nomePilha.Push(111);
            nomePilha.Pop();
            nomePilha.Pop();
            nomePilha.Pop();
            nomePilha.Push(900);

            Console.WriteLine(nomePilha.Peek());*/








            /*Guid guid = Guid.NewGuid();
            string myGui = guid.ToString();
            string[] guidBroke = myGui.Split('-');

            Stack<string> pilha = new Stack<string>();

            foreach (var item in guidBroke)
            {
                pilha.Push(item);
            }

            foreach (var item in pilha)
            {
                Console.WriteLine(item);
            }

            Console.WriteLine($"\nÚltimo valor da pilha:\n{pilha.Peek()}");*/








            /*List<string> mylist = new List<string>();

            for (int i = 0; i < 1000; i++)
            {
                string guid = Guid.NewGuid().ToString().Split('-')[2];
                mylist.Add(guid);
                Console.WriteLine(guid);
            }

            bool hasDuplicated = mylist.GroupBy(x => x).Any(g => g.Count() < 1);
            Console.WriteLine(hasDuplicated);*/





            int i = 0;
            while (i < 100)
            {
                //Task.Delay(1000);
                Thread.Sleep(500);
                i++;
                Console.Write(i.ToString() + ", ");
            }
        }
    }
}
