﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Carros.Models;

namespace Carros.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CarroController : ControllerBase
    {
        private static List<Carro> carros = new List<Carro>
        {
            

        };

        [HttpPost]
        public ActionResult<List<Carro>>
            AddCarro(Carro novo)
        {
            if (novo.Id == 0 && carros.Count > 0)
                novo.Id = carros[carros.Count - 1].Id + 1;

            carros.Add(novo);
            return Ok(carros);
        }

        [HttpPut("{id}")]
        public ActionResult<List<Carro>>
            SolicitarCarro(int id)
        {
            var pesquisa = carros.Find(x => x.Id == id);

            if (pesquisa is null)
                return NotFound("Carro não encontrado");

            
                pesquisa.Alugado = !pesquisa.Alugado;
            

            return Ok(pesquisa);
        }

        [HttpGet("{id}")]
        public ActionResult<Carro>
        VerificarCarro(int id)
        {
            var unico = carros.Find(x => x.Id == id);

            if (unico is null)
                return NotFound("Este carro não foi encontrado");

            return Ok(unico);
        }


        
        


        [HttpPut("modelo/{modelo}")]
        public ActionResult
            DevolverCarro(int id)
        {
            var pesquisa = carros.Find(x => x.Id == id);

            if (pesquisa is null)
                return NotFound("Carro não encontrado");

           
                pesquisa.Alugado = !pesquisa.Alugado;
            

            return Ok($"{pesquisa.Modelo} devolvido com sucesso!");
        }


    }
}
